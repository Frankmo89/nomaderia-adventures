# Textos listos para copiar

## Bio de Instagram (máx. 150 caracteres)

Tú eliges el parque. Nosotros armamos el plan.
Aquí nadie se pierde… nomás se encuentra.
Haz el quiz gratis 👇

(Link de la bio: https://nomaderia.com)

## Bio de TikTok (máx. 80 caracteres)

Tú eliges el parque. Nosotros armamos el plan. Quiz gratis 👇

## Facebook: Presentación (máx. 101 caracteres)

Tú eliges el parque. Nosotros armamos el plan. Aquí nadie se pierde… nomás se encuentra.

## WhatsApp Business: Descripción

Nomaderia arma el plan de tu viaje a un parque nacional. Itinerario completo por $49 USD, revisado por un agente de viajes certificado (TAP). Aquí nadie se pierde… nomás se encuentra. Haz el quiz gratis en nomaderia.com.

## Post del carrusel (archivos 04, 05 y 06)

### Instagram

¿Planeas ir a un parque nacional? Empieza por aquí.

Estrenamos imagen. El pin marca tu destino, la montaña es tu próximo parque y el punto naranja es la fogata al final del día.

Así funciona Nomaderia:
1. Contestas el quiz gratis.
2. Te recomendamos el parque nacional que mejor va contigo.
3. Un agente de viajes certificado arma y revisa tu itinerario completo por $49 USD.

Aquí nadie se pierde… nomás se encuentra.
Haz el quiz gratis. El link está en la bio.

#ParquesNacionales #Senderismo #SanDiego #SoCal #HikingEnEspañol

### Facebook

¿Planeas ir a un parque nacional? Empieza por aquí.

Estrenamos imagen. El pin marca tu destino, la montaña es tu próximo parque y el punto naranja es la fogata al final del día.

Así funciona Nomaderia:
1. Contestas el quiz gratis.
2. Te recomendamos el parque nacional que mejor va contigo.
3. Un agente de viajes certificado arma y revisa tu itinerario completo por $49 USD.

Aquí nadie se pierde… nomás se encuentra.
Haz el quiz gratis aquí 👉 https://nomaderia.com

## Cambio de foto de perfil (Facebook lo publica solo)

Nueva imagen, el mismo plan: llevarte a tu próximo parque nacional. 📍

## Historia (archivo 08)

Sticker de enlace: https://nomaderia.com
Texto del sticker: Haz el quiz
