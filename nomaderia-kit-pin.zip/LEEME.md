# Kit de marca Nomaderia: el Pin

Aprobado el 3 de octubre de 2026.

## Qué hay en cada carpeta

**repo/** va tal cual a GitHub. Copia `public/` y `docs/` en la raíz del repo, en la rama `brand/pin-logo` (o sube este ZIP entero a la raíz de esa rama: el prompt incluye el paso para descomprimirlo). Luego pásale al agente el prompt de `prompts/1-bot-tecnico.md`.
- `public/favicon.ico`, `public/favicon.svg`: ícono de la pestaña del navegador.
- `public/apple-touch-icon.png`: ícono cuando guardan el sitio en el iPhone.
- `public/icons/`: íconos de la app (PWA). Cierra la tarea pendiente de los íconos 192/512.
- `public/og-image.png`: la imagen que sale al compartir nomaderia.com en Facebook y WhatsApp.
- `public/brand/`: el logo para el navbar, el footer y el admin.
- `docs/brand.md`: las reglas del logo para los bots.

**logos/** son los archivos maestros. Usa SVG siempre que se pueda; PNG para Canva, CapCut y Descript.
- `horizontal`: el logo por defecto. `-oscuro` para fondos oscuros o fotos. `-ink` y `-blanco` a una tinta.
- `vertical`: para espacios cuadrados o altos.
- `simbolo`: el pin solo.
- `wordmark`: solo el nombre.
- `avatar`: foto de perfil. `icono-app`: ícono con esquinas redondas.

**redes/** son las piezas listas para subir, más `textos-para-copiar.md` con bios y captions.
- 01: foto de perfil para Instagram, Facebook, TikTok y WhatsApp.
- 02: la imagen para compartir el sitio (la misma de `og-image.png`).
- 03: portada de Facebook.
- 04, 05 y 06: el carrusel de estreno, en ese orden.
- 07: el último cuadro de cada reel.
- 08: historia con espacio para el sticker de enlace.
- 09: portadas de destacadas de Instagram.
- 10 y 11: plantillas transparentes. Ponlas encima de tus fotos o videos en Canva o CapCut.
- 12 y 13: marca de agua blanca para la esquina de los videos.

**prompts/** son los textos para el bot técnico, el bot de marketing y Gemini.

## Reglas cortas

- El nombre en texto se escribe "Nomaderia": con N mayúscula y sin acento.
- "IA" y el punto del sol siempre van en naranja. El logo es la única excepción a la regla de "naranja solo en el Hero".
- No estires el logo, no le cambies colores, no le pongas sombra y no lo vuelvas a dibujar.
- En una foto con mucho detalle, usa la plantilla 10 u 11 para que el logo se lea.
- Nunca lo pongas junto al logo del NPS.
- Tamaño mínimo: el logo horizontal mide al menos 120 px de ancho y el pin solo 24 px de alto.

## Colores

| Nombre | Hex | Uso |
| --- | --- | --- |
| Cloud | #FBFAF7 | Fondo principal |
| Ink | #13211A | Texto |
| Trail Green | #1F6F43 | El color de la marca |
| Forest | #14201A | Fondo oscuro |
| Fogata | #D97706 | La chispa: IA, el sol, una palabra por pantalla |
