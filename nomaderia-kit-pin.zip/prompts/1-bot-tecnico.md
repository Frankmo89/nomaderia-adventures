Read CLAUDE.md and use @workspace.

Task: install the new Nomaderia logo ("El Pin") across the site: navbar, footer, admin sidebar, favicons, PWA icons, the default OG image, the footer slogan and the brand-name spelling in index.html. One Draft PR on the branch `brand/pin-logo`.

Step 0 - assets
- If `nomaderia-kit-pin.zip` is in the repo root: unzip it into a temp folder outside src/, copy `repo/public/*` into `public/` (overwrite the old favicon.ico) and `repo/docs/brand.md` into `docs/brand.md`, then delete the zip and the temp folder. Commit only those files. Do not commit the zip's `logos/`, `redes/` or `prompts/` folders.
- If there is no zip, the files are already on the branch. Check that every file below exists and stop if any is missing.
- Use the files as they are. Do not edit, optimize, rename or regenerate them:
  - public/favicon.ico (16/32/48), public/favicon.svg, public/apple-touch-icon.png (180)
  - public/icons/icon-192.png, public/icons/icon-512.png, public/icons/icon-maskable-512.png
  - public/og-image.png (1200x630)
  - public/brand/nomaderia-horizontal.svg (light grounds), public/brand/nomaderia-horizontal-oscuro.svg (dark grounds and photos), public/brand/nomaderia-vertical.svg, public/brand/nomaderia-vertical-oscuro.svg, public/brand/nomaderia-simbolo.svg, public/brand/nomaderia-simbolo-oscuro.svg
  - docs/brand.md (the logo rules; treat it as the source of truth for this task)

Step 1 - audit. Before changing code, list in the PR description every place that renders the brand logo, a favicon, an app icon or the OG image (grep for BRAND_ASSETS.logo, placeholder.svg, favicon, manifest, og:image, and lucide Mountain used next to the text "NOMADERIA"). Stop and report if you find a logo usage this prompt does not cover.

Step 2 - index.html
- Replace the icon links with:
  <link rel="icon" href="/favicon.ico" sizes="32x32" />
  <link rel="icon" href="/favicon.svg" type="image/svg+xml" />
  <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
  Remove the link to /placeholder.svg.
- theme-color: #1F6F43.
- og:image and twitter:image: https://nomaderia.com/og-image.png. Add og:image:width 1200, og:image:height 630 and og:image:alt "Nomaderia: tú eliges el parque, nosotros armamos el plan. Aquí nadie se pierde… nomás se encuentra." Keep the sync comment that points to src/config/assets.ts.
- Brand spelling: replace "Nomadería" with "Nomaderia" in the title, author, description, og:title, og:description, twitter:title and twitter:description. Change nothing else in those strings.

Step 3 - public/manifest.webmanifest
- icons: exactly three entries: /icons/icon-192.png (192x192, image/png, purpose "any"), /icons/icon-512.png (512x512, image/png, purpose "any"), /icons/icon-maskable-512.png (512x512, image/png, purpose "maskable").
- theme_color "#1F6F43", background_color "#FBFAF7". Keep name, short_name, description, start_url and display.

Step 4 - src/config/assets.ts
- logo: "/brand/nomaderia-horizontal.svg"
- Add logoOnDark: "/brand/nomaderia-horizontal-oscuro.svg", symbol: "/brand/nomaderia-simbolo.svg", symbolOnDark: "/brand/nomaderia-simbolo-oscuro.svg".
- defaultOgImage: "https://nomaderia.com/og-image.png"
- Remove the TODO about uploading the logo to Supabase.

Step 5 - new component src/components/brand/Logo.tsx
- Props: variant?: "default" | "onDark" (default "default"), className?: string.
- Renders one <img> with src from BRAND_ASSETS (logo or logoOnDark), alt="Nomaderia", width={533} height={130} so the browser reserves space, loading="eager", decoding="async". The caller sets the height with Tailwind (for example "h-8 w-auto").
- No text fallback and no onError state.

Step 6 - use <Logo /> in place of the current logo markup
- Navbar: mirror the existing color logic. Where the bar shows white text (transparent over the hero, not scrolled) use variant="onDark"; where it shows foreground text (scrolled or solid) use the default. Apply the same rule to the mobile menu header based on its background. Size: "h-8 w-auto md:h-9".
- Footer (dark background): variant="onDark", "h-8 w-auto". Replace the line under the logo, "Tu primera aventura empieza aquí.", with "Aquí nadie se pierde… nomás se encuentra." (keep the real ellipsis character and the accent in "nomás"). This is the only copy change in this PR.
- Admin sidebar logo (dark sidebar): variant="onDark".
- Remove the logoError state and the Mountain + "NOMADERIA" fallback wherever you replace it.
- Leave decorative Mountain icons that are not the brand logo (for example the 404 hero icon and the eyebrow on Sobre Nosotros) as they are.

Step 7 - JSON-LD in src/pages/Index.tsx: in the Organization/TravelAgency object, set "logo" to "https://nomaderia.com/icons/icon-512.png" (add the field if it is missing). Do not change any other JSON-LD field. If you see stale pricing there (priceRange "$29-$49 USD"), log it in docs/pending-tasks.md instead of fixing it here.

Step 8 - delete public/placeholder.svg only if grep shows no other reference to it.

Step 9 - docs
- docs/design-system.md: add a "Logo" section that summarizes docs/brand.md and links to it. State that the logo is the one exception to the "orange only in the Hero" rule.
- CLAUDE.md: add docs/brand.md to the docs list if CLAUDE.md has one.
- docs/decisions.md: add the next ADR number, "Logo: El Pin", dated 2026-10-03, two or three lines: what changed and why (a pin reads as "we take you to a place", works at favicon size, keeps nomaderIA with IA in fogata; slogan "Aquí nadie se pierde… nomás se encuentra.").

Do NOT touch: supabase.auth, the has_role RPC or any Supabase query; routing; Stripe or pricing; Hero copy and colors; fonts (Playfair stays for now); any page copy except the footer line in step 6 and the brand spelling in step 2; the asset files listed in step 0.

Before opening the PR:
- tsc --noEmit and npm run build pass.
- dist/ contains favicon.ico, favicon.svg, apple-touch-icon.png, icons/icon-192.png, icons/icon-512.png, icons/icon-maskable-512.png, og-image.png and the six files in brand/.
- No reference to placeholder.svg remains, and no zip or temp folder is committed.
- Title the Draft PR "Brand: install El Pin logo, favicons, PWA icons and OG image". Add screenshots at 390 px wide (navbar over the hero, navbar scrolled, footer) if your tools allow.

Finish by updating docs/pending-tasks.md:
- Log this change with the PR number.
- Mark "Replace PWA fallback icons (192/512)" as done.
- Add these manual tasks for Frank: re-scrape nomaderia.com in the Facebook Sharing Debugger after deploy; check the favicon and the navbar logo on iPhone Safari in a private tab; change the profile photo on Instagram, Facebook, TikTok and WhatsApp Business.
- Add this copy follow-up for a separate PR: the Hero headline "Tu Concierge de Aventuras en Español" and other "primer/primera" and "en español" taglines conflict with the new brand rules in docs/brand.md.
