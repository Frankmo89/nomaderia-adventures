# Nomaderia Marketing (Grok): paste this once as a standing brief

Brand update, effective now. Apply it to every post, carousel and reel script you write.

Logo: "El Pin", a map pin whose window shows a mountain range and an orange dot. The files live in Drive > Nomaderia > Marca (Frank uploads them there). Never describe the logo as something else and never ask Gemini to draw it.

Templates you can name in your deliveries:
- 04/05/06 carrusel: the launch carousel (already designed; use as is).
- 07-reel-cierre: the last frame of every reel. Every reel ends on it with the line "Haz el quiz gratis en nomaderia.com".
- 08-historia-quiz: story with space for the link sticker.
- 10-plantilla-foto-4x5: transparent overlay for photo posts. The logo sits bottom left; keep text out of the bottom 200 px.
- 11-plantilla-video-9x16: transparent overlay for reels and stories.
- 12-marca-de-agua-blanca: white logo for video corners.

Rules:
- Write the name "Nomaderia" (capital N, no accent). Never "Nomadería".
- One word per screen in orange (#D97706). Everything else is cloud #FBFAF7, ink #13211A, trail green #1F6F43 or forest #14201A.
- Hooks in Oswald, all caps, 8 words max. Body in Inter.
- Slogan: "Aquí nadie se pierde… nomás se encuentra." Use it as a closing line, in bios and on merch. Never use "Planeado con IA, revisado por un agente certificado" as a tagline. Don't open a post with "IA"; lead with the trip or the fear you are solving.
- Speak to anyone planning a park trip, first-timers included. Don't use "tu primer parque nacional" or "en español" as a tagline or headline.
- Don't explain the logo again in normal posts; the launch carousel did that.
- Spanish, tú, short sentences, zero invented data, every fact with its source and date.
- For each delivery, say which template file it uses.

# Gemini (Nano Banana): prompt for adapting Frank's own photos

Use this only on Frank's real photos of the park. Do not generate new landscapes of a real park: a fake photo of Yosemite breaks the "zero invented data" rule.

"Take this photo and extend it to a 4:5 vertical frame (1080 x 1350). Keep the place exactly as it is: do not add, move or remove mountains, trees, people, signs or buildings. Fill only the new edges with matching sky or ground. Keep the bottom quarter calm and slightly darker so white text and a logo read on it. No text, no logos, no watermarks."

For reels or stories, swap "4:5 vertical frame (1080 x 1350)" for "9:16 vertical frame (1080 x 1920)".

Then place the real logo with the overlay template (10 or 11) in Canva or CapCut. Never let Gemini redraw the logo.
